from django.apps import AppConfig


class SetkaEditorConfig(AppConfig):
    name = 'setka_editor'
